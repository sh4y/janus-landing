# Janus Chrome Extension

This directory contains the source code for the Janus Contextual Translator Chrome Extension (MV3).

## Development

1.  Open Chrome and navigate to `chrome://extensions/`.
2.  Enable "Developer mode" using the toggle switch in the top right corner.
3.  Click the "Load unpacked" button.
4.  Select the `/Users/shay/janusC/janus-chrome-extension` directory.

The extension should now be loaded and active. Remember to reload the extension from the `chrome://extensions/` page after making changes to the code. 