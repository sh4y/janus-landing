/**
 * premium.js - Handles all premium feature functionality for Janus
 */

// Storage keys
const PREMIUM_STORAGE_KEYS = {
    premiumKey: 'janusPremiumKey',
    premiumStatus: 'janusPremiumStatus',
    premiumExpiry: 'janusPremiumExpiry',
    premiumFeatures: 'janusPremiumFeatures'
};

// Premium feature definitions
const PREMIUM_FEATURES = {
    ADVANCED_TRANSLATION_MODEL: { key: 'advancedModel', enabled: false },
    CUSTOM_TRANSLATIONS: { key: 'customTranslations', enabled: false },
    MULTI_LANGUAGE: { key: 'multiLanguage', enabled: false },
    ANALYTICS: { key: 'analytics', enabled: false },
    VOCABULARY_LIST: { key: 'vocabularyList', enabled: false }
};

/**
 * Check if the user has an active premium subscription
 * @returns {Promise<boolean>} Promise resolving to premium status
 */
function isPremiumUser() {
    return new Promise((resolve) => {
        chrome.storage.local.get([PREMIUM_STORAGE_KEYS.premiumStatus, PREMIUM_STORAGE_KEYS.premiumExpiry], (result) => {
            const status = result[PREMIUM_STORAGE_KEYS.premiumStatus] || false;
            const expiry = result[PREMIUM_STORAGE_KEYS.premiumExpiry] || 0;
            
            // Check if premium and not expired
            const isActive = status && Date.now() < expiry;
            resolve(isActive);
        });
    });
}

/**
 * Get active premium features
 * @returns {Promise<Object>} Promise resolving to feature object with enabled state
 */
function getPremiumFeatures() {
    return new Promise((resolve) => {
        chrome.storage.local.get([PREMIUM_STORAGE_KEYS.premiumFeatures], (result) => {
            // Start with default features (all disabled)
            const defaultFeatures = { ...PREMIUM_FEATURES };
            
            // Override with saved feature state if available
            const savedFeatures = result[PREMIUM_STORAGE_KEYS.premiumFeatures] || {};
            const mergedFeatures = { ...defaultFeatures, ...savedFeatures };
            
            resolve(mergedFeatures);
        });
    });
}

/**
 * Validate a premium key
 * @param {string} key The premium key to validate
 * @returns {Promise<boolean>} Promise resolving to validation result
 */
async function validatePremiumKey(key) {
    // This would normally make an API call to validate the key
    // For now, implement simple validation
    if (!key || typeof key !== 'string') {
        return false;
    }
    
    const isValidFormat = key.length >= 16 && /[a-zA-Z]/.test(key) && /[0-9]/.test(key);
    
    if (isValidFormat) {
        // Set premium status in storage
        const expiryDate = Date.now() + (365 * 24 * 60 * 60 * 1000); // 1 year from now
        await setDefaultPremiumFeatures();
        
        chrome.storage.local.set({
            [PREMIUM_STORAGE_KEYS.premiumKey]: key,
            [PREMIUM_STORAGE_KEYS.premiumStatus]: true,
            [PREMIUM_STORAGE_KEYS.premiumExpiry]: expiryDate
        });
        
        return true;
    }
    
    return false;
}

/**
 * Set default enabled state for premium features
 */
async function setDefaultPremiumFeatures() {
    const defaultEnabledFeatures = {};
    
    // Enable all premium features by default
    Object.keys(PREMIUM_FEATURES).forEach(featureKey => {
        defaultEnabledFeatures[featureKey] = {
            ...PREMIUM_FEATURES[featureKey],
            enabled: true
        };
    });
    
    chrome.storage.local.set({
        [PREMIUM_STORAGE_KEYS.premiumFeatures]: defaultEnabledFeatures
    });
}

/**
 * Update a specific premium feature's enabled state
 * @param {string} featureKey The feature key to update
 * @param {boolean} enabled Whether the feature should be enabled
 */
async function updatePremiumFeature(featureKey, enabled) {
    const features = await getPremiumFeatures();
    
    if (features[featureKey]) {
        features[featureKey].enabled = !!enabled;
        
        chrome.storage.local.set({
            [PREMIUM_STORAGE_KEYS.premiumFeatures]: features
        });
        
        return true;
    }
    
    return false;
}

/**
 * Deactivate premium subscription
 */
function deactivatePremium() {
    chrome.storage.local.set({
        [PREMIUM_STORAGE_KEYS.premiumStatus]: false,
        [PREMIUM_STORAGE_KEYS.premiumKey]: null
    });
}

/**
 * Apply premium settings to the current request
 * @param {Object} requestData The request data to modify
 * @returns {Promise<Object>} Promise resolving to modified request data
 */
async function applyPremiumFeaturesToRequest(requestData) {
    const isPremium = await isPremiumUser();
    const features = await getPremiumFeatures();
    
    if (!isPremium) {
        return requestData;
    }
    
    let modifiedRequest = { ...requestData };
    
    // Apply advanced translation model if enabled
    if (features.ADVANCED_TRANSLATION_MODEL?.enabled) {
        modifiedRequest.useAdvancedModel = true;
    }
    
    // Apply custom translations if enabled
    if (features.CUSTOM_TRANSLATIONS?.enabled) {
        // Get custom translations from storage and add to request
        chrome.storage.local.get(['janusCustomTranslations'], (result) => {
            modifiedRequest.customTranslations = result.janusCustomTranslations || {};
        });
    }
    
    return modifiedRequest;
}

// Export functionality using ES6 export syntax
export {
    PREMIUM_STORAGE_KEYS,
    PREMIUM_FEATURES,
    isPremiumUser,
    getPremiumFeatures,
    validatePremiumKey,
    updatePremiumFeature,
    deactivatePremium,
    applyPremiumFeaturesToRequest
}; 