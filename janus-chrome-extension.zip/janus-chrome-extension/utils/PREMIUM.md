# Janus Premium Feature Implementation

This document describes how premium features are implemented in the Janus extension.

## Architecture

Premium functionality is isolated in a dedicated module (`premium.js`) to maintain clean separation of concerns. The module handles:

1. Premium status checking and validation
2. Premium feature configuration
3. Premium feature application to requests
4. Premium storage management

## How to Use

### Importing the Premium Module

```javascript
import { 
  isPremiumUser, 
  getPremiumFeatures, 
  validatePremiumKey,
  updatePremiumFeature,
  deactivatePremium,
  applyPremiumFeaturesToRequest
} from '../utils/premium.js';
```

### Checking Premium Status

```javascript
const isPremium = await isPremiumUser();
if (isPremium) {
  // Enable premium UI/features
}
```

### Applying Premium Features to Requests

```javascript
let requestData = {
  textContent,
  targetLanguage: 'es',
  // Other base options
};

// Apply premium features to request
requestData = await applyPremiumFeaturesToRequest(requestData);

// Use the enhanced request
sendToApi(requestData);
```

## Premium Features

Current premium features include:

| Feature | Key | Description |
|---------|-----|-------------|
| Advanced Translation Model | `ADVANCED_TRANSLATION_MODEL` | Uses more sophisticated models for higher quality translations |
| Custom Translations | `CUSTOM_TRANSLATIONS` | User-defined translations that override default ones |
| Multi-Language Support | `MULTI_LANGUAGE` | Learning multiple languages simultaneously |
| Analytics | `ANALYTICS` | Learning progress tracking and statistics |
| Vocabulary List | `VOCABULARY_LIST` | Saving and exporting translated words |

## Storage Structure

Premium data is stored in Chrome's `storage.local` with the following keys:

- `janusPremiumKey`: The user's premium license key
- `janusPremiumStatus`: Boolean indicating if premium is active
- `janusPremiumExpiry`: Timestamp when premium subscription expires
- `janusPremiumFeatures`: Object with feature configuration

## Adding New Premium Features

To add a new premium feature:

1. Add the feature to the `PREMIUM_FEATURES` object in `premium.js`
2. Add feature-specific handling in `applyPremiumFeaturesToRequest()` 
3. Update UI components in popup.js/options.js to expose the feature

## Future Enhancements

- Server-side validation of premium keys
- Subscription management integration
- Usage analytics for premium features
- More granular feature control 