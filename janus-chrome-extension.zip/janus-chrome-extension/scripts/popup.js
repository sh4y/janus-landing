console.log("Popup script loaded.");

// Keys for storage (consistent with background.js and potentially content.js)
const stateKey = 'janusIsActive';
const pauseEndTimeKey = 'janusPauseEndTime'; // New key for pause end time
const settingsKeys = {
    maxBlocks: 'janusMaxBlocks',
    targetLang: 'janusTargetLang',
    azureUrl: 'janusAzureUrl', // Added Azure URL key from the other file
    allowToggle: 'janusAllowToggle', // New setting for click-to-toggle functionality
    difficultyLevel: 'janusDifficultyLevel', // ADDED: Difficulty setting key
    premiumKey: 'janusPremiumKey', // Added premium key storage
    advancedMode: 'janusAdvancedMode' // NEW: Advanced mode key
};

// Default values (consistent with other scripts)
const defaultSettings = {
    [settingsKeys.maxBlocks]: 5,
    [settingsKeys.targetLang]: 'es',
    [settingsKeys.azureUrl]: '', // Default empty Azure URL
    [settingsKeys.allowToggle]: true, // Default to allowing toggle
    [settingsKeys.difficultyLevel]: 'intermediate', // ADDED: Default difficulty
    [settingsKeys.premiumKey]: '', // Default empty premium key
    [settingsKeys.advancedMode]: false // NEW: Default advanced mode
};

// Import premium functionality
import { validatePremiumKey, isPremiumUser, PREMIUM_FEATURES } from '../utils/premium.js';

// --- DOM Elements (Declare with let, assign in DOMContentLoaded) ---
let toggleButton;
let targetLangSelect;
let maxBlocksInput;
let maxBlocksValueSpan;
let statusMessageDiv;
let pauseButton;
let pauseStatusDiv;
let allowToggleCheckbox;
let difficultySelect;
let premiumToggleButton;
let premiumPanel;
let premiumSectionHeader;
let closePremiumPanelButton;
let upgradeButton;
let validateKeyButton;
let premiumKeyStatus;
let toggleAdvancedModeBtn; // NEW: Advanced mode button element

// NEW: Azure Function URL Placeholder (REPLACE THIS)
const AZURE_FUNCTION_URL_CHECK_STATUS = 'https://janustranslate-dubpdpbbaeefetd3.northeurope-01.azurewebsites.net/api/PremiumKeyValidation'; 
const AZURE_FUNCTION_URL_TOGGLE_ADVANCED = 'https://janustranslate-dubpdpbbaeefetd3.northeurope-01.azurewebsites.net/api/AdvancedModeSettings'; // Correct Azure Function for advanced mode

// --- State ---
let pauseIntervalId = null; // To store the interval timer for pause countdown
let premiumActive = false; // Track if premium is active

// --- Functions ---

// Function to load the current active state AND pause state
function loadInitialState() {
    console.log("Requesting state and pause info from background...");
    // Get both the active state and the pause end time
    chrome.storage.local.get([stateKey, pauseEndTimeKey], (result) => {
        if (chrome.runtime.lastError) {
            console.error("Error getting initial state/pause:", chrome.runtime.lastError.message);
            return;
        }

        const isActive = result[stateKey] || false; // Default to false if not set
        const pauseEndTime = result[pauseEndTimeKey];

        console.log("Initial state:", isActive, "Pause End Time:", pauseEndTime);
        updateToggleButton(isActive);
        updatePauseButton(pauseEndTime);
    });
}

// Function to update the PAUSE button appearance and status text
function updatePauseButton(pauseEndTime) {
    clearInterval(pauseIntervalId); // Clear any existing interval
    pauseIntervalId = null;

    const now = Date.now();

    if (pauseEndTime && pauseEndTime > now) {
        // Currently paused
        pauseButton.textContent = "Resume";
        pauseButton.classList.add('resuming');

        const updateRemainingTime = () => {
            const remainingMs = pauseEndTime - Date.now();
            if (remainingMs <= 0) {
                pauseStatusDiv.textContent = "Resuming now...";
                clearInterval(pauseIntervalId);
                pauseIntervalId = null;
                // Optionally force UI update or rely on storage change listener
                 loadInitialState(); // Re-check state
            } else {
                const remainingSeconds = Math.round(remainingMs / 1000);
                const minutes = Math.floor(remainingSeconds / 60);
                const seconds = remainingSeconds % 60;
                pauseStatusDiv.textContent = `Paused. Resuming in ${minutes}m ${seconds < 10 ? '0' : ''}${seconds}s`;
            }
        };

        updateRemainingTime(); // Initial update
        pauseIntervalId = setInterval(updateRemainingTime, 1000); // Update every second

    } else {
        // Not paused (or pause expired)
        pauseButton.textContent = "Pause (15 min)";
        pauseButton.classList.remove('resuming');
        pauseStatusDiv.textContent = ""; // Clear status text

         // If pauseEndTime exists but is in the past, clear it from storage
         if (pauseEndTime) {
             chrome.storage.local.remove(pauseEndTimeKey, () => {
                 if (chrome.runtime.lastError) {
                     console.error("Error removing expired pause time:", chrome.runtime.lastError);
                 }
             });
         }
    }
}

// Function to update the toggle button appearance
function updateToggleButton(isActive) {
    if (isActive) {
        toggleButton.textContent = "Deactivate";
        toggleButton.classList.add('active'); // Add class for styling
        toggleButton.classList.remove('inactive');
    } else {
        toggleButton.textContent = "Activate";
        toggleButton.classList.add('inactive');
        toggleButton.classList.remove('active');
    }
}

// Function to load settings from storage
function loadSettings() {
    console.log("Loading settings from storage...");
    // Create the object to get from storage
    const keysToGet = {
        [settingsKeys.maxBlocks]: defaultSettings[settingsKeys.maxBlocks],
        [settingsKeys.targetLang]: defaultSettings[settingsKeys.targetLang],
        [settingsKeys.allowToggle]: defaultSettings[settingsKeys.allowToggle],
        [settingsKeys.difficultyLevel]: defaultSettings[settingsKeys.difficultyLevel], // Keep loading difficulty unconditionally
        [settingsKeys.premiumKey]: defaultSettings[settingsKeys.premiumKey], // Keep loading key for now (maybe needed elsewhere?)
        [settingsKeys.advancedMode]: defaultSettings[settingsKeys.advancedMode] // NEW: Load advanced mode setting
    };

    chrome.storage.local.get(keysToGet, (settings) => {
        if (chrome.runtime.lastError) {
            console.error("Error loading settings:", chrome.runtime.lastError);
            showStatusMessage("Error loading settings.", "error");
            return;
        }
        console.log("Loaded settings:", settings);
        targetLangSelect.value = settings[settingsKeys.targetLang];
        maxBlocksInput.value = settings[settingsKeys.maxBlocks];
        maxBlocksValueSpan.textContent = settings[settingsKeys.maxBlocks]; 
        allowToggleCheckbox.checked = settings[settingsKeys.allowToggle];
        difficultySelect.value = settings[settingsKeys.difficultyLevel]; // Set difficulty dropdown value unconditionally
        
        // Attempt to load premium status on popup open if ID exists
        // This will enable/disable UI based on status, but settings are already loaded above.
        initializePremiumUI(); 
    });
}

// Function to save settings to storage (Restored to original logic)
function saveSettings() {
    const newMaxBlocks = parseInt(maxBlocksInput.value, 10);
    const newTargetLang = targetLangSelect.value;
    const newAllowToggle = allowToggleCheckbox.checked;
    const newDifficulty = difficultySelect.value; // Get difficulty unconditionally

    console.log(`Saving settings: maxBlocks=${newMaxBlocks}, targetLang=${newTargetLang}, allowToggle=${newAllowToggle}, difficulty=${newDifficulty}`);

    // Updated validation for slider range 0-50
    if (isNaN(newMaxBlocks) || newMaxBlocks < 0 || newMaxBlocks > 50) {
        showStatusMessage("Text blocks per page must be between 0 and 50.", "error");
        return;
    }

    const settingsToSave = {
        [settingsKeys.maxBlocks]: newMaxBlocks,
        [settingsKeys.targetLang]: newTargetLang,
        [settingsKeys.allowToggle]: newAllowToggle,
        [settingsKeys.difficultyLevel]: newDifficulty // Save difficulty unconditionally
    };

    chrome.storage.local.set(settingsToSave, () => {
        if (chrome.runtime.lastError) {
            console.error("Error saving settings:", chrome.runtime.lastError);
            showStatusMessage("Error saving settings.", "error");
        } else {
            console.log("Settings saved successfully.");
            showStatusMessage("Settings saved!", "success");
            maxBlocksValueSpan.textContent = newMaxBlocks;
        }
    });
}

// New function to show status messages with animation
function showStatusMessage(message, type, timeoutMs = 2000) {
    statusMessageDiv.textContent = message;
    statusMessageDiv.className = type;
    statusMessageDiv.classList.add('status-animation');
    setTimeout(() => {
        statusMessageDiv.classList.remove('status-animation');
        statusMessageDiv.textContent = "";
        statusMessageDiv.className = '';
    }, timeoutMs);
}

// --- Event Listeners ---

document.addEventListener('DOMContentLoaded', () => {
    // --- Assign DOM Elements NOW --- 
    toggleButton = document.getElementById('toggle-active');
    targetLangSelect = document.getElementById('target-lang');
    maxBlocksInput = document.getElementById('max-words');
    maxBlocksValueSpan = document.getElementById('max-words-value');
    statusMessageDiv = document.getElementById('status-message');
    pauseButton = document.getElementById('pause-button');
    pauseStatusDiv = document.getElementById('pause-status');
    allowToggleCheckbox = document.getElementById('allow-toggle');
    difficultySelect = document.getElementById('difficulty-level');
    premiumToggleButton = document.getElementById('premium-toggle');
    premiumPanel = document.getElementById('premium-features-panel');
    premiumSectionHeader = document.querySelector('.premium-section-header');
    closePremiumPanelButton = document.getElementById('close-premium-panel');
    upgradeButton = document.getElementById('upgrade-button');
    validateKeyButton = document.getElementById('validate-key-button');
    premiumKeyStatus = document.getElementById('premium-key-status');
    toggleAdvancedModeBtn = document.getElementById('toggle-advanced-mode-btn');

    // Installation ID display
    const installationIdValue = document.getElementById('installation-id-value');
    chrome.storage.local.get(['installationId'], (result) => {
        if (chrome.runtime.lastError) {
            installationIdValue.textContent = 'Error';
        } else if (result && result.installationId) {
            installationIdValue.textContent = result.installationId;
        } else {
            installationIdValue.textContent = 'Not found';
        }
    });

    // --- Load Initial State and Settings ---
    loadInitialState();
    loadSettings();
    
    // --- Setup tooltip positioning ---
    setupTooltips();

    // --- Attach Event Listeners NOW ---
    // Listener for the slider input 
    maxBlocksInput.addEventListener('input', () => {
        maxBlocksValueSpan.textContent = maxBlocksInput.value;
        saveSettingsAndNotify();
    });

    // Listener for target language change
    targetLangSelect.addEventListener('change', () => {
        saveSettingsAndNotify();
    });

    // Listener for allow toggle checkbox
    allowToggleCheckbox.addEventListener('change', () => {
        saveSettingsAndNotify();
    });

    // Listener for difficulty dropdown change (Restored - always save)
    difficultySelect.addEventListener('change', () => {
        saveSettingsAndNotify();
    });

    // Toggle button listener
    toggleButton.addEventListener('click', () => {
        console.log("Toggle button clicked.");
        chrome.runtime.sendMessage({ action: 'toggleState' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Error toggling state:", chrome.runtime.lastError.message);
                showStatusMessage("Error toggling state.", "error");
                return;
            }
            if (response && response.success) {
                console.log("Toggle successful. New state:", response.newState);
                updateToggleButton(response.newState);
            } else {
                console.error("Failed to toggle state via background.");
                showStatusMessage("Error toggling state.", "error");
            }
        });
    });

    // Pause button listener
    pauseButton.addEventListener('click', () => {
        const currentText = pauseButton.textContent;

        if (currentText.includes("Pause")) {
            // Request to PAUSE
            const pauseDurationMinutes = 15;
            const now = Date.now();
            const endTime = now + pauseDurationMinutes * 60 * 1000;
            console.log(`Requesting pause until ${new Date(endTime).toLocaleString()}`);

            chrome.storage.local.set({ [pauseEndTimeKey]: endTime }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Error saving pause end time:", chrome.runtime.lastError);
                    showStatusMessage("Error pausing.", "error");
                } else {
                    console.log("Pause end time saved.");
                    updatePauseButton(endTime); // Update UI immediately
                }
            });

        } else {
            // Request to RESUME (Clear pause)
            console.log("Requesting manual resume.");

            chrome.storage.local.remove(pauseEndTimeKey, () => {
                if (chrome.runtime.lastError) {
                    console.error("Error clearing pause end time:", chrome.runtime.lastError);
                    showStatusMessage("Error resuming.", "error");
                } else {
                    console.log("Pause end time cleared for manual resume.");
                    updatePauseButton(null); // Update UI immediately
                }
            });
        }
    });

    // Premium panel toggle handling
    function openPremiumPanel() {
        premiumPanel.classList.add('active');
    }

    function closePremiumPanel() {
        premiumPanel.classList.remove('active');
    }

    premiumToggleButton.addEventListener('click', (e) => {
        e.stopPropagation();
        openPremiumPanel();
    });

    premiumSectionHeader.addEventListener('click', (e) => {
        if (e.target !== premiumToggleButton && !premiumToggleButton.contains(e.target)) {
            openPremiumPanel();
        }
    });

    closePremiumPanelButton.addEventListener('click', closePremiumPanel);

    // Upgrade button handling
    upgradeButton.addEventListener('click', async (e) => {
        e.preventDefault(); // Prevent form submission if inside a form
        upgradeButton.disabled = true;
        const originalText = upgradeButton.textContent;
        upgradeButton.textContent = 'Loading...';
        showStatusMessage('Preparing payment...', 'info', 2000);

        // Stripe payment link
        const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/test_9B66oJ0zp4pR1t4eM52VG00';
        let installationId;
        try {
            installationId = await getInstallationId();
        } catch (err) {
            showStatusMessage('Error: Could not retrieve installation ID.', 'error', 4000);
            upgradeButton.disabled = false;
            upgradeButton.textContent = originalText;
            return;
        }
        // Validate installationId
        if (!installationId || typeof installationId !== 'string' || installationId.trim().length < 6) {
            showStatusMessage('Invalid installation ID. Please reinstall or contact support.', 'error', 4000);
            upgradeButton.disabled = false;
            upgradeButton.textContent = originalText;
            return;
        }
        // Optionally: regex validation (alphanumeric, dashes, etc.)
        // if (!/^[\w-]{6,}$/.test(installationId)) {
        //     showStatusMessage('Invalid installation ID format.', 'error', 4000);
        //     upgradeButton.disabled = false;
        //     upgradeButton.textContent = originalText;
        //     return;
        // }
        // Construct payment URL
        const params = new URLSearchParams({
            client_reference_id: installationId
        });
        const paymentUrl = `${STRIPE_PAYMENT_LINK}?${params.toString()}`;
        // Open payment link in new tab
        let win = window.open(paymentUrl, '_blank');
        if (win) {
            win.focus();
            showStatusMessage('Payment page opened in a new tab.', 'success', 3000);
        } else {
            showStatusMessage('Popup blocked! Please allow popups and try again.', 'error', 5000);
        }
        // Reset button state after short delay
        setTimeout(() => {
            upgradeButton.disabled = false;
            upgradeButton.textContent = originalText;
        }, 2000);
        closePremiumPanel();
    });

    // Premium key validation handling -> Now Premium Status Check
    validateKeyButton.addEventListener('click', async () => {
        // Clear previous status and disable button during check
        premiumKeyStatus.textContent = "Checking status...";
        premiumKeyStatus.className = "";
        validateKeyButton.disabled = true; 

        try {
            const installationId = await getInstallationId(); 

            if (!installationId) {
                premiumKeyStatus.textContent = "Error: Could not retrieve installation ID.";
                premiumKeyStatus.className = "invalid";
                return;
            }
            
            console.log(`Checking premium status for installation ID: ${installationId}`);

            const response = await fetch(AZURE_FUNCTION_URL_CHECK_STATUS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'check_installation', installation_id: installationId }),
            });

            if (!response.ok) {
                 const errorText = await response.text();
                 throw new Error(`Azure function request failed: ${response.status} ${response.statusText}. ${errorText}`);
            }

            const result = await response.json(); // Expects { success: boolean, is_premium: boolean, ... }

            if (result.is_premium) {
                premiumKeyStatus.textContent = "Premium is ACTIVE for this installation.";
                premiumKeyStatus.className = "valid";
                premiumActive = true;
                if (toggleAdvancedModeBtn) toggleAdvancedModeBtn.disabled = false;
            } else {
                premiumKeyStatus.textContent = "Premium is NOT ACTIVE for this installation.";
                premiumKeyStatus.className = "invalid";
                premiumActive = false;
                if (toggleAdvancedModeBtn) toggleAdvancedModeBtn.disabled = true;
            }

        } catch (error) {
            console.error("Error checking premium status:", error);
            premiumKeyStatus.textContent = "Could not check premium status. Please try again.";
            premiumKeyStatus.className = "invalid";
            premiumActive = false;
            if (toggleAdvancedModeBtn) toggleAdvancedModeBtn.disabled = true;
        } finally {
            validateKeyButton.disabled = false; // Re-enable button
            validateKeyButton.textContent = 'Check Premium Status'; // Always reset to correct label
        }
    });

    // Function to retrieve installation ID from storage
    async function getInstallationId() {
        const MAX_ATTEMPTS = 15; // Try for up to 3 seconds (15 * 200ms)
        const RETRY_DELAY_MS = 200;

        for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try {
                const result = await new Promise((resolve, reject) => {
                    chrome.storage.local.get(['installationId'], (res) => {
                        if (chrome.runtime.lastError) {
                            reject(chrome.runtime.lastError);
                        } else {
                            resolve(res);
                        }
                    });
                });

                if (result && result.installationId) {
                    console.log(`[getInstallationId] Found ID on attempt ${attempt}:`, result.installationId);
                    return result.installationId; // Found it!
                }

                // ID not found yet, wait before retrying
                console.log(`[getInstallationId] Attempt ${attempt}: ID not found, waiting ${RETRY_DELAY_MS}ms...`);
                await new Promise(resolve => setTimeout(resolve, RETRY_DELAY_MS));

            } catch (error) {
                console.error(`[getInstallationId] Error during attempt ${attempt}:`, error);
                // Don't retry on storage errors, just throw
                throw new Error(`Failed to get installation ID due to storage error: ${error.message}`);
            }
        }

        // If loop finishes without finding the ID
        console.error("[getInstallationId] Failed to get installation ID after multiple attempts.");
        throw new Error("Installation ID not found after waiting.");
    }
    
    // Setup dynamic tooltip positioning
    function setupTooltips() {
        const tooltipIcons = document.querySelectorAll('.tooltip-icon');
        
        tooltipIcons.forEach(icon => {
            // For premium panel tooltips, we'll add a class to help with styling
            const isPremiumPanel = icon.closest('.premium-panel') !== null;
            if (isPremiumPanel) {
                icon.classList.add('premium-panel-tooltip');
            }
        });
    }

    // Load advanced mode state
    chrome.storage.local.get([settingsKeys.advancedMode, settingsKeys.premiumKey], (result) => {
        if (toggleAdvancedModeBtn) {
            toggleAdvancedModeBtn.disabled = !premiumActive;
            updateAdvancedModeButton(result[settingsKeys.advancedMode]);
        }
        if (difficultySelect) difficultySelect.disabled = false;
    });

    // Advanced mode button listener
    if (toggleAdvancedModeBtn) {
        toggleAdvancedModeBtn.addEventListener('click', async () => {
            console.log('Advanced Mode button clicked');
            // Show immediate feedback
            showStatusMessage('Toggling advanced mode...', 'info', 3000); // 3s for toggling
            toggleAdvancedModeBtn.disabled = true;
            toggleAdvancedModeBtn.textContent = 'Toggling...';
            let installationId = '';
            try {
                installationId = await getInstallationId();
            } catch (e) {
                showStatusMessage('Error: Missing installation ID.', 'error', 3000);
                toggleAdvancedModeBtn.disabled = false;
                updateAdvancedModeButton();
                return;
            }
            try {
                const response = await fetch(AZURE_FUNCTION_URL_TOGGLE_ADVANCED, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ installationId })
                });
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`Azure function failed: ${response.status} ${response.statusText}. ${errorText}`);
                }
                const result = await response.json(); // Expects { installationId, mode }
                if (typeof result.mode !== 'boolean') {
                    showStatusMessage('Error: Unexpected response from server.', 'error', 3000);
                    updateAdvancedModeButton();
                    return;
                }
                chrome.storage.local.set({ [settingsKeys.advancedMode]: result.mode }, () => {
                    updateAdvancedModeButton(result.mode);
                    showStatusMessage(result.mode ? 'Advanced Mode enabled.' : 'Advanced Mode disabled.', 'success', 3000);
                });
            } catch (error) {
                showStatusMessage('Error toggling advanced mode: ' + error.message, 'error', 3000);
            } finally {
                toggleAdvancedModeBtn.disabled = false;
                // Always update button text to reflect current state
                chrome.storage.local.get([settingsKeys.advancedMode], (result) => {
                    updateAdvancedModeButton(result[settingsKeys.advancedMode]);
                });
            }
        });
    }
});

// Storage change listener
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
        let settingsChanged = false;
        let stateChanged = false;
        let pauseChanged = false;
        let premiumStatusPotentiallyChanged = false; // Flag for potential re-check

        console.log("Popup detected storage change:", changes);

        // Check if core settings changed
        if (settingsKeys.maxBlocks in changes) {
            const newValue = changes[settingsKeys.maxBlocks].newValue;
            maxBlocksInput.value = newValue;
            maxBlocksValueSpan.textContent = newValue;
            settingsChanged = true;
        }
        if (settingsKeys.targetLang in changes) {
            targetLangSelect.value = changes[settingsKeys.targetLang].newValue;
            settingsChanged = true;
        }
        if (settingsKeys.allowToggle in changes) { 
            allowToggleCheckbox.checked = changes[settingsKeys.allowToggle].newValue;
            settingsChanged = true;
        }
        // Check if difficulty setting changed (update UI regardless of premium state here, but disable state is handled elsewhere)
        if (settingsKeys.difficultyLevel in changes) { 
            difficultySelect.value = changes[settingsKeys.difficultyLevel].newValue;
            settingsChanged = true;
        }

        // Check if activation state changed
        if (stateKey in changes) {
            updateToggleButton(changes[stateKey].newValue);
            stateChanged = true;
        }

        // Check if pause state changed
        if (pauseEndTimeKey in changes) {
            updatePauseButton(changes[pauseEndTimeKey].newValue);
            pauseChanged = true;
        }

        // Check if advanced mode state changed
        if (settingsKeys.advancedMode in changes && toggleAdvancedModeBtn) {
            updateAdvancedModeButton(changes[settingsKeys.advancedMode].newValue);
        }

        // Optionally show a subtle indication that settings were updated externally
        if (settingsChanged || stateChanged || pauseChanged) {
            // You could briefly highlight the changed element or show a small message
            // For now, just logging is sufficient.
        }
    }
});

// New function to handle saving and notification
function saveSettingsAndNotify() {
    const newMaxBlocks = parseInt(maxBlocksInput.value, 10);
    const newTargetLang = targetLangSelect.value;
    const newAllowToggle = allowToggleCheckbox.checked;
    const newDifficulty = difficultySelect.value; // Get difficulty value unconditionally

    // Basic validation (can be expanded)
    if (isNaN(newMaxBlocks) || newMaxBlocks < 0 || newMaxBlocks > 50) {
        console.warn("Slider value out of range during input, not saving yet.");
        return;
    }

    const settingsToSave = {
        [settingsKeys.maxBlocks]: newMaxBlocks,
        [settingsKeys.targetLang]: newTargetLang,
        [settingsKeys.allowToggle]: newAllowToggle, // Include allow toggle setting
        [settingsKeys.difficultyLevel]: newDifficulty, // Save difficulty setting unconditionally
        [settingsKeys.advancedMode]: toggleAdvancedModeBtn ? toggleAdvancedModeBtn.checked : defaultSettings[settingsKeys.advancedMode] // NEW: Save advanced mode setting
    };

    // NOTE: No conditional logic based on premiumActive needed here anymore for saving.

    chrome.storage.local.set(settingsToSave, () => {
        if (chrome.runtime.lastError) {
            console.error("Error saving settings during slider input:", chrome.runtime.lastError);
        } else {
            // Notify the active content script
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].id) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: 'janusSettingsUpdated' }, (response) => {
                        if (chrome.runtime.lastError) {
                            console.log("Could not send settings update message to content script (maybe it's not injected yet?):", chrome.runtime.lastError.message);
                        } else {
                            console.log("Content script acknowledged settings update.", response);
                        }
                    });
                } else {
                    console.log("No active tab found to notify.");
                }
            });
        }
    });
}

function updateAdvancedModeButton(isEnabled) {
    if (!toggleAdvancedModeBtn) return;
    if (isEnabled) {
        toggleAdvancedModeBtn.textContent = 'Disable Advanced Mode';
        toggleAdvancedModeBtn.classList.add('active');
    } else {
        toggleAdvancedModeBtn.textContent = 'Enable Advanced Mode';
        toggleAdvancedModeBtn.classList.remove('active');
    }
}

// Migration logic: if janusMaxBlocks is not set but janusMaxWords is, copy the value over
chrome.storage.local.get(['janusMaxBlocks', 'janusMaxWords'], (result) => {
    if (result.janusMaxBlocks === undefined && result.janusMaxWords !== undefined) {
        chrome.storage.local.set({ janusMaxBlocks: result.janusMaxWords });
    }
}); 