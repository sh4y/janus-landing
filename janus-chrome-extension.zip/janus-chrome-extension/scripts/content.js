const LOG_LEVEL = 'debug'; // Change to 'info', 'warn', 'error', or 'none' to reduce output
function log(level, ...args) {
    const levels = { debug: 0, info: 1, warn: 2, error: 3, none: 4 };
    if (levels[level] >= levels[LOG_LEVEL]) {
        if (level === 'warn') console.warn(...args);
        else if (level === 'error') console.error(...args);
        else console.log(...args);
    }
}

console.log("Janus content script loaded.");

const stateKey = 'janusIsActive';
const pauseEndTimeKey = 'janusPauseEndTime'; // ADDED: Key for pause end time
let currentIsActive = false; // Local cache of the main state
let currentPauseEndTime = null; // ADDED: Local cache for pause end time
const translatedClass = 'janus-translated';
// DEPRECATED: let maxWordsToTranslate = 5; // Will be loaded from storage
let tooltipElement; // Will hold the tooltip DOM element
let currentAnimationDelay = 0; // Global animation delay counter
let isActivating = false; // ADDED: Flag to prevent concurrent activation runs

// Shared settings keys and defaults (consistent with options.js)
const settingsKeys = {
    maxBlocks: 'janusMaxBlocks',
    targetLang: 'janusTargetLang',
    allowToggle: 'janusAllowToggle',
    difficultyLevel: 'janusDifficultyLevel',
    wordSpacingLevel: 'janusWordSpacingLevel',
    installationId: 'installationId'
};

const defaultSettings = {
    [settingsKeys.maxBlocks]: 5,
    [settingsKeys.targetLang]: 'es',
    [settingsKeys.allowToggle]: true,
    [settingsKeys.difficultyLevel]: 'intermediate',
    [settingsKeys.wordSpacingLevel]: 'immediate'
};

// Migration logic: if janusMaxBlocks is not set but janusMaxWords is, copy the value over
chrome.storage.local.get(['janusMaxBlocks', 'janusMaxWords'], (result) => {
    if (result.janusMaxBlocks === undefined && result.janusMaxWords !== undefined) {
        chrome.storage.local.set({ janusMaxBlocks: result.janusMaxWords });
    }
});

// Basic English stop words list (can be expanded)
const STOP_WORDS = new Set([
    'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'from', 'with', 'of', 'for', 'by', 'as', 'is', 'are', 'was', 'were', 'be', 'being', 'been', 'it', 'its', 'that', 'which', 'who', 'whom', 'this', 'these', 'those', 'i', 'you', 'he', 'she', 'we', 'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'her', 'our', 'their', 'what', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
]);

// Feature Keys (align with background.js Features object)
const FeatureKeys = {
    CORE_TRANSLATION: 'coreTranslation',
    TOOLTIP: 'tooltip',
    CLICK_TO_TOGGLE: 'clickToToggle',
    WORD_COUNT_LIMIT: 'wordCountLimit',
    PAUSE_FUNCTIONALITY: 'pauseFunctionality'
};

// Local cache for active features
let activeFeatures = [];

// Performance optimization flags
const PERF_OPTS = {
    USE_INTERSECTION_OBSERVER: true,   // Process visible content first
    USE_TEXT_CONTENT_CACHE: true,      // Cache processed text to avoid redundant work
    PRIORITIZE_VISIBLE_ELEMENTS: true, // Focus on elements in the viewport first
    MAX_WORDS_PER_ELEMENT: 2,          // Limit translations per element for better distribution
    ELEMENT_WORD_SPACING: 50           // Minimum character spacing between selected words in same element
};

// Cache processed content to avoid re-parsing identical content
const processedTextCache = new Map();
const observedElements = new Set();
let intersectionObserver = null;

let listenersActive = false;

// --- Tooltip & Style Management ---

function createTooltip() {
    tooltipElement = document.createElement('div');
    tooltipElement.id = 'janus-tooltip';
    tooltipElement.style.position = 'absolute';
    tooltipElement.style.visibility = 'hidden';
    tooltipElement.style.backgroundColor = 'black';
    tooltipElement.style.color = 'white';
    tooltipElement.style.padding = '5px';
    tooltipElement.style.borderRadius = '3px';
    tooltipElement.style.zIndex = '10000'; // Ensure it's on top
    tooltipElement.style.fontSize = '12px';
    tooltipElement.style.pointerEvents = 'none'; // Prevent tooltip from interfering with mouse events
    document.body.appendChild(tooltipElement);
}

function showTooltip(event, text) {
    if (!tooltipElement) createTooltip();
    tooltipElement.textContent = text;
    tooltipElement.style.visibility = 'visible';
    // Position near mouse, slightly offset
    tooltipElement.style.left = `${event.pageX + 10}px`;
    tooltipElement.style.top = `${event.pageY + 10}px`;
}

function hideTooltip() {
    if (tooltipElement) {
        tooltipElement.style.visibility = 'hidden';
    }
}

// Inject some basic CSS for the translated words (can be refined)
function injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
        /* REMOVED janus-reveal animation */

        .${translatedClass} {
            background-color: yellow !important; /* Fixed yellow background */
            color: black !important;             /* Fixed black text */
            cursor: pointer;                     /* Indicate interactivity */
            /* outline: none !important;           Optional: remove outline if desired */
            /* REMOVED animation property */
            /* REMOVED transition property */
            /* Ensure inline display doesn't break layout too much */
            display: inline-block; 
            vertical-align: baseline; /* Adjust alignment if needed */
            padding: 1px 2px; /* Optional: Add slight padding */
            border-radius: 2px; /* Optional: Slightly rounded corners */
        }
        /* REMOVED hover style - base style is now the desired yellow */

        /* Block translation shimmer/overlay */
        .janus-translating-block {
            position: relative !important;
        }
        .janus-translating-block::after {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(90deg, rgba(255,255,200,0.1) 0%, rgba(255,255,200,0.4) 50%, rgba(255,255,200,0.1) 100%);
            pointer-events: none;
            z-index: 9999;
            animation: janus-shimmer 1.2s infinite linear;
        }
        @keyframes janus-shimmer {
            0% { background-position: -200px 0; }
            100% { background-position: 200px 0; }
        }
    `;
    document.head.appendChild(style);
    log('debug', "[Janus Debug] Styles injected into <head> with static yellow background and shimmer overlay."); // DEBUG LOG
}

// Centralized settings utility
function getJanusSettings(keys = Object.values(settingsKeys), callback) {
    chrome.storage.local.get(defaultSettings, (settings) => {
        if (chrome.runtime.lastError) {
            log('error', "[Janus] Error retrieving settings:", chrome.runtime.lastError);
            callback({ ...defaultSettings });
        } else {
            // Only return requested keys
            const result = {};
            keys.forEach(key => result[key] = settings[key] !== undefined ? settings[key] : defaultSettings[key]);
            callback(result);
        }
    });
}

// Central translation request function
async function requestTranslation({ installationId, language, words, level, isPremium, context }) {
    // Central endpoint URL (should match your backend)
    const url = 'https://janustranslate-apim.azure-api.net/translate/central';
    // Sanitize level
    const allowedLevels = ['intermediate', 'basic', 'advanced'];
    let safeLevel = allowedLevels.includes(level) ? level : 'intermediate';
    // Truncate context to 4000 characters if present
    let safeContext = context ? context.slice(0, 4000) : undefined;
    const payload = {
        installation_id: installationId,
        language,
        level: safeLevel,
        words,
        ...(safeContext ? { context: safeContext } : {})
    };
    log('debug', '[Janus][requestTranslation] Called with:', { url, payload, isPremium });
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        log('debug', '[Janus][requestTranslation] Fetch response status:', response.status);
        if (!response.ok) throw new Error(`API error: ${response.status}`);
        const data = await response.json();
        log('debug', '[Janus][requestTranslation] FULL RAW RESPONSE:', JSON.stringify(data, null, 2)); // MODIFIED: Output full endpoint result stringified
        log('debug', '[Janus][requestTranslation] Response data:', data);
        return data;
    } catch (e) {
        log('error', '[Janus][requestTranslation] Translation request failed:', e, e.name, e.message);
        throw e;
    }
}

// Utility: Wrap all occurrences of words in a block of text with <span> for toggling/tooltip
function wrapTranslatedWordsInText(text, words, originalWordsMap) {
    // Sort words by length descending to avoid partial overlaps
    const sortedWords = [...words].sort((a, b) => b.length - a.length);
    let result = text;
    sortedWords.forEach(word => {
        // Use word boundaries, case-insensitive
        const regex = new RegExp(`\\b${word}\\b`, 'gi');
        result = result.replace(regex, match => {
            const original = originalWordsMap && originalWordsMap[word] ? originalWordsMap[word] : match;
            return `<span class=\"${translatedClass}\" data-original=\"${original}\" data-translated=\"${match}\" data-janus-state=\"translated\">${match}</span>`;
        });
    });
    return result;
}

// --- DOM Utilities ---
// Wraps selected words in a text node with spans, returns array of created spans
function wrapWordsInTextNode(node, candidates) {
    // Sort candidates by start index DESC to avoid index issues
    candidates.sort((a, b) => b.startIndex - a.startIndex);
    let currentNode = node;
    const spans = [];
    candidates.forEach(candidate => {
        if (currentNode.nodeType !== Node.TEXT_NODE || candidate.endIndex > currentNode.textContent.length) return;
        // Split after the word
        let remainingNode = currentNode.splitText(candidate.endIndex);
        // Split before the word
        let wordNode = currentNode.splitText(candidate.startIndex);
        // Create span
        const span = document.createElement('span');
        span.textContent = candidate.word + ' ⏳';
        span.dataset.original = candidate.word;
        span.dataset.janusState = 'loading';
        span.classList.add('janus-loading');
        wordNode.parentNode.replaceChild(span, wordNode);
        spans.push({ span, originalWord: candidate.word });
        currentNode = span.previousSibling || currentNode;
    });
    return spans;
}

// Restores all translated spans to original text
function restoreOriginalText() {
    const translatedElements = document.querySelectorAll('.' + translatedClass);
    translatedElements.forEach(span => {
        const originalText = span.dataset.original || span.textContent;
        if (span.parentNode) {
            span.replaceWith(document.createTextNode(originalText));
        }
    });
}

// --- Standard Pathway Logic ---
async function activateJanusStandard({ paragraphsData, finalSelection, installationId, language, level, maxWordsToTranslate }) {
    log('debug', '[Janus] Using standard translation pathway.');
    // Group selected candidates by their original text node
    const nodesToModify = new Map();
    finalSelection.forEach(candidate => {
        if (!nodesToModify.has(candidate.node)) {
            nodesToModify.set(candidate.node, []);
        }
        nodesToModify.get(candidate.node).push(candidate);
    });
    // Wrap words in spans and collect for translation
    const spansToTranslate = [];
    nodesToModify.forEach((candidatesInNode, originalNode) => {
        const spans = wrapWordsInTextNode(originalNode, candidatesInNode);
        spansToTranslate.push(...spans);
    });
    // Batch translation requests
    const batchSize = 20;
    for (let i = 0; i < spansToTranslate.length; i += batchSize) {
        const batch = spansToTranslate.slice(i, i + batchSize);
        let words = batch.map(item => item.originalWord);
        // Filter out stop words
        words = words.filter(w => !STOP_WORDS.has(w.toLowerCase()));
        log('debug', '[Janus][activateJanusStandard] Requesting translation for batch:', words);
        try {
            const response = await requestTranslation({
                installationId,
                language,
                words,
                level,
                isPremium: false
            });
            log('debug', '[Janus][activateJanusStandard] Translation response:', response);
            if (response && response.mapping && Array.isArray(response.mapping)) {
                // Build a lookup map from original to translated (case-insensitive)
                const mappingMap = new Map();
                response.mapping.forEach(entry => {
                    mappingMap.set(entry.source.toLowerCase(), entry.translation);
                });
                batch.forEach((item) => {
                    const originalWord = item.originalWord;
                    let translation = mappingMap.get(originalWord.toLowerCase());
                    if (typeof translation === 'string') {
                        // Preserve case
                        if (originalWord === originalWord.toLowerCase()) translation = translation.toLowerCase();
                        else if (originalWord === originalWord.toUpperCase()) translation = translation.toUpperCase();
                        else if (originalWord.length > 0 && originalWord[0] === originalWord[0].toUpperCase() && originalWord.substring(1) === originalWord.substring(1).toLowerCase()) {
                            translation = translation.length > 0 ? translation[0].toUpperCase() + translation.substring(1).toLowerCase() : translation;
                        }
                        item.span.textContent = translation;
                        item.span.classList.remove('janus-loading');
                        item.span.classList.add(translatedClass);
                        item.span.dataset.translated = translation;
                        item.span.dataset.janusState = 'translated';
                    } else {
                        // No translation found for this word or translation is not a string
                        item.span.textContent = originalWord;
                        item.span.classList.remove('janus-loading');
                        item.span.classList.add('janus-error');
                        item.span.dataset.janusState = 'api-error';
                    }
                });
            } else if (response && response.translations && response.translations.length === batch.length) {
                // Old API: response.translations is an array
                batch.forEach((item, index) => {
                    const originalWord = item.originalWord;
                    let translation = response.translations[index];
                    // Preserve case
                    if (originalWord === originalWord.toLowerCase()) translation = translation.toLowerCase();
                    else if (originalWord === originalWord.toUpperCase()) translation = translation.toUpperCase();
                    else if (originalWord.length > 0 && originalWord[0] === originalWord[0].toUpperCase() && originalWord.substring(1) === originalWord.substring(1).toLowerCase()) {
                        translation = translation.length > 0 ? translation[0].toUpperCase() + translation.substring(1).toLowerCase() : translation;
                    }
                    item.span.textContent = translation;
                    item.span.classList.remove('janus-loading');
                    item.span.classList.add(translatedClass);
                    item.span.dataset.translated = translation;
                    item.span.dataset.janusState = 'translated';
                });
            } else {
                log('error', '[Janus] Standard translation response invalid:', response);
                batch.forEach(item => {
                    item.span.textContent = item.originalWord;
                    item.span.classList.remove('janus-loading');
                    item.span.classList.add('janus-error');
                    item.span.dataset.janusState = 'api-error';
                });
            }
        } catch (e) {
            log('error', '[Janus][activateJanusStandard] Standard translation batch failed:', e);
            batch.forEach(item => {
                item.span.textContent = item.originalWord;
                item.span.classList.remove('janus-loading');
                item.span.classList.add('janus-error');
                item.span.dataset.janusState = 'error';
            });
        }
    }
}

// --- Main activation logic (centralized, updated) ---
async function activateJanus(caller = 'unknown') {
    log('debug', `[Janus] activateJanus called by: ${caller}.`);
    if (isActivating) {
        log('warn', '[Janus] activateJanus called while already activating. Aborting.');
        return;
    }
    isActivating = true;
    try {
        chrome.storage.local.get(['installationId'], (result) => {
            if (chrome.runtime.lastError) {
                log('error', '[Janus] Error retrieving installation ID:', chrome.runtime.lastError);
                isActivating = false;
                return;
            }
            const installationId = result.installationId;
            if (!installationId) {
                log('error', '[Janus] No installation ID found in storage! Aborting activation.');
                isActivating = false;
                return;
            }
            getJanusSettings(Object.values(settingsKeys), async (settings) => {
                const language = settings[settingsKeys.targetLang];
                const level = settings[settingsKeys.difficultyLevel];
                // --- Block selection logic (NEW) ---
                const paragraphSelector = 'p, li, div, span';
                const headerSelector = 'h1, h2, h3, h4, h5, h6';
                const allElements = Array.from(document.querySelectorAll(paragraphSelector)).filter(el => el.offsetParent !== null && el.innerText.trim().length > 0);
                // Exclude headers (element is a header or inside a header)
                let elements = allElements.filter(el => {
                    if (el.matches(headerSelector) || el.closest(headerSelector)) return false;
                    return true;
                });
                // Prioritize <p> and <li> elements
                let prioritizedElements = elements.filter(el => el.tagName === 'P' || el.tagName === 'LI');
                // Only allow div/span if class/id contains article, content, body, main
                const allowDivSpan = el => {
                    if (el.tagName === 'P' || el.tagName === 'LI') return true;
                    if (el.tagName === 'DIV' || el.tagName === 'SPAN') {
                        const attr = (el.className + ' ' + el.id).toLowerCase();
                        return /article|content|body|main/.test(attr);
                    }
                    return false;
                };
                let secondaryElements = elements.filter(el => (el.tagName === 'DIV' || el.tagName === 'SPAN') && allowDivSpan(el));
                elements = [...prioritizedElements, ...secondaryElements];
                // Exclude elements with class/id containing nav, footer, header, sidebar, paywall, media, etc.
                const excludeKeywords = /nav|footer|header|sidebar|paywall|media|layout|crawler|series-nav|links-container|inset|wrapper/;
                elements = elements.filter(el => {
                    const attr = (el.className + ' ' + el.id).toLowerCase();
                    return !excludeKeywords.test(attr);
                });
                // Filter to blocks with at least 10 words
                const wordRegex = /\b[\p{L}’'-]{3,}\b/gu;
                const blockCandidates = elements.map(el => {
                    // Clone the element to avoid modifying the DOM
                    const clone = el.cloneNode(true);
                    // Remove all <a> elements from the clone
                    const links = clone.querySelectorAll('a');
                    links.forEach(link => link.remove());
                    // Use the clone's innerText, which now excludes link text
                    const text = clone.innerText;
                    const words = text.match(wordRegex) || [];
                    return { el, text, words, wordCount: words.length };
                }).filter(item => item.wordCount >= 10);
                // Pick up to 10 blocks (by order on page)
                const maxBlocks = settings[settingsKeys.maxBlocks];
                const selectedBlocks = blockCandidates.slice(0, maxBlocks);
                log('debug', `[Janus] Selected ${selectedBlocks.length} blocks for translation.`);
                // --- CONCURRENCY-LIMITED PARALLEL REQUESTS (max 5 at once) ---
                const MAX_CONCURRENT = 5;
                const tasks = selectedBlocks.map(block => async () => {
                    block.el.classList.add('janus-translating-block');
                    const shimmerTimeout = setTimeout(() => {
                        block.el.classList.remove('janus-translating-block');
                    }, 3000);
                    try {
                        // Send the entire block as the only item in the words array, but limit to 400 characters
                        let blockText = block.text.trim();
                        if (blockText.length > 400) {
                            blockText = blockText.slice(0, 400);
                        }
                        const words = [blockText];
                        console.log('[Janus][BlockTranslation] Text being sent to LLM:', blockText);
                        const response = await requestTranslation({
                            installationId,
                            language,
                            words,
                            level,
                            isPremium: false
                        });
                        log('debug', '[Janus][BlockTranslation] Response:', response);
                        // If mapping is present, replace only the matched words/phrases in text nodes
                        if (response && response.mapping && Array.isArray(response.mapping) && response.mapping.length > 0) {
                            // Sort mapping by phrase length (descending, by number of characters)
                            const mapping = [...response.mapping].sort((a, b) => b.source.length - a.source.length);
                            // For regex escaping
                            function escapeRegExp(string) {
                                return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                            }
                            // Walk text nodes in the block and replace mapped phrases only in text nodes
                            const nodeWalker = document.createTreeWalker(block.el, NodeFilter.SHOW_TEXT, null, false);
                            let textNode;
                            while ((textNode = nodeWalker.nextNode())) {
                                let text = textNode.textContent;
                                if (!text || !text.trim()) continue;
                                // Find all non-overlapping matches for any phrase
                                let matches = [];
                                mapping.forEach(({ source, translation }) => {
                                    let pattern;
                                    if (/\s/.test(source)) {
                                        pattern = escapeRegExp(source);
                                    } else {
                                        pattern = `\\b${escapeRegExp(source)}\\b`;
                                    }
                                    const regex = new RegExp(pattern, 'gi');
                                    let match;
                                    while ((match = regex.exec(text)) !== null) {
                                        matches.push({
                                            phrase: source,
                                            translation,
                                            startIndex: match.index,
                                            endIndex: match.index + match[0].length,
                                            matchedText: match[0]
                                        });
                                    }
                                });
                                // Remove overlapping matches: sort by start, then by longest match
                                matches.sort((a, b) => a.startIndex - b.startIndex || b.endIndex - b.startIndex - (a.endIndex - a.startIndex));
                                let nonOverlapping = [];
                                let lastEnd = -1;
                                for (const m of matches) {
                                    if (m.startIndex >= lastEnd) {
                                        nonOverlapping.push(m);
                                        lastEnd = m.endIndex;
                                    }
                                }
                                if (nonOverlapping.length === 0) continue;
                                // Build new HTML string for this text node
                                let result = '';
                                let lastIdx = 0;
                                for (const m of nonOverlapping) {
                                    // Add text before match
                                    result += text.slice(lastIdx, m.startIndex);
                                    let translation = m.translation;
                                    // Preserve case (use the matched text, not the mapping key)
                                    if (m.matchedText === m.matchedText.toLowerCase()) translation = translation.toLowerCase();
                                    else if (m.matchedText === m.matchedText.toUpperCase()) translation = translation.toUpperCase();
                                    else if (m.matchedText.length > 0 && m.matchedText[0] === m.matchedText[0].toUpperCase() && m.matchedText.substring(1) === m.matchedText.substring(1).toLowerCase()) {
                                        translation = translation.length > 0 ? translation[0].toUpperCase() + translation.substring(1).toLowerCase() : translation;
                                    }
                                    // Replace only the matched text, optionally wrap in a span for styling
                                    result += `<span class=\"${translatedClass}\" data-original=\"${m.matchedText.replace(/\"/g, '&quot;')}\" data-translated=\"${translation.replace(/\"/g, '&quot;')}\" data-janus-state=\"translated\">${translation}</span>`;
                                    lastIdx = m.endIndex;
                                }
                                // Add remaining text
                                result += text.slice(lastIdx);
                                // Replace text node with fragment
                                const frag = document.createRange().createContextualFragment(result);
                                textNode.parentNode.replaceChild(frag, textNode);
                            }
                        } else {
                            // Fallback: replace the whole block's text if only a single translation is present
                            let translation = null;
                            if (response && Array.isArray(response.translations) && response.translations.length > 0) {
                                translation = response.translations[0];
                            } else if (response && response.mapping && Array.isArray(response.mapping) && response.mapping.length > 0) {
                                translation = response.mapping[0].translation;
                            }
                            if (typeof translation === 'string') {
                                block.el.innerText = translation;
                            } else {
                                log('warn', '[Janus][BlockTranslation] No valid translation in response:', response);
                            }
                        }
                    } catch (e) {
                        log('error', '[Janus][BlockTranslation] Error translating block:', e);
                    } finally {
                        clearTimeout(shimmerTimeout);
                        block.el.classList.remove('janus-translating-block');
                    }
                });
                // Promise pool runner
                async function runPromisePool(tasks, maxConcurrent) {
                    let i = 0;
                    const results = [];
                    const executing = [];
                    const enqueue = async () => {
                        if (i === tasks.length) return Promise.resolve();
                        const task = tasks[i++]();
                        results.push(task);
                        const p = task.then(() => executing.splice(executing.indexOf(p), 1));
                        executing.push(p);
                        let r = Promise.resolve();
                        if (executing.length >= maxConcurrent) {
                            r = Promise.race(executing);
                        }
                        await r;
                        return enqueue();
                    };
                    await enqueue();
                    return Promise.allSettled(results);
                }
                await runPromisePool(tasks, MAX_CONCURRENT);
                isActivating = false;
            });
        });
    } catch (e) {
        isActivating = false;
        throw e;
    }
}

// Function to handle deactivation: Remove the spans and restore original text
// REVISED for simplicity
function deactivateJanus() {
    log('debug', "[Janus Debug Distro] Deactivation logic running...");
    currentIsActive = false;
    hideTooltip(); // Ensure tooltip is hidden

    // Find all translated spans
    const translatedElements = document.querySelectorAll('.' + translatedClass);
    log('debug', `[Janus Debug Distro] Removing ${translatedElements.length} translated elements.`);

    translatedElements.forEach(span => {
        // Replace the span with its original text content
        const originalText = span.dataset.original || span.textContent; // Fallback to textContent
        try {
            // Check parent still exists before replacing
             if (span.parentNode) {
                 span.replaceWith(document.createTextNode(originalText));
             } else {
                 log('warn', "[Janus Debug Distro] Span parent disappeared before deactivation replacement:", span);
             }
        } catch (e) {
             log('error', "[Janus Debug Distro] Error reverting span:", e, span);
        }
    });
    log('debug', `[Janus Debug Distro] Finished deactivation.`);
}

// Function to update state and trigger actions
function handleStateChange(isActive, pauseEndTime, newActiveFeatures) {
    log('debug', `[Janus Debug] handleStateChange received: isActive=${isActive}, pauseEndTime=${pauseEndTime ? new Date(pauseEndTime).toLocaleString() : null}, features=${newActiveFeatures?.join(', ')}`);

    // Update local caches immediately
    const previousIsActive = currentIsActive;
    const previousPauseEndTime = currentPauseEndTime;
    const previousActiveFeatures = [...activeFeatures]; // Copy previous features
    currentIsActive = isActive;
    currentPauseEndTime = pauseEndTime;
    activeFeatures = newActiveFeatures || activeFeatures; // Update features if provided

    // Calculate the effective state: active AND not paused
    const now = Date.now();
    const isPaused = currentPauseEndTime && currentPauseEndTime > now;
    const isEffectivelyActive = currentIsActive && !isPaused;
    const wasEffectivelyActive = previousIsActive && (!previousPauseEndTime || previousPauseEndTime <= now);

    log('debug', `[Janus Debug] Effective state check: isPaused=${isPaused}, isEffectivelyActive=${isEffectivelyActive}, wasEffectivelyActive=${wasEffectivelyActive}`);

    // Check if the *effective* state or feature set actually changed
    const featuresChanged = JSON.stringify(activeFeatures) !== JSON.stringify(previousActiveFeatures);
    if (!featuresChanged && isEffectivelyActive === wasEffectivelyActive) {
        log('debug', `[Janus Debug] Effective state and features haven't changed. No action needed.`);
        return;
    }

    // If features changed, we might need to remove old listeners/state even if the effective state remains the same
    if (featuresChanged && wasEffectivelyActive) {
        log('debug', "[Janus Debug] Features changed while active, performing cleanup...");
        // Determine which features were removed
        const removedFeatures = previousActiveFeatures.filter(f => !activeFeatures.includes(f));
        cleanupFeatures(removedFeatures); // Function to cleanup specific feature state/listeners
        // If the extension is still effectively active, we will re-initialize below
    }

    // Ensure we don't run activation/deactivation unnecessarily or concurrently
    const existingSpans = document.querySelectorAll('.' + translatedClass);
    if (isEffectivelyActive && existingSpans.length > 0) {
        log('debug', "[Janus Debug] Already effectively active with existing spans, potential duplication? Re-activating for safety.");
        // If somehow we get here (active state signal, but spans exist), ensure consistency
        deactivateJanus(); // Clear existing state first
    } else if (!isEffectivelyActive && existingSpans.length === 0) {
        log('debug', "[Janus Debug] Already effectively inactive with no spans, no action needed.");
        return;
    }

    if (isEffectivelyActive) {
        log('debug', "[Janus Debug] Effective state is active. Running initializeFeatures...");
        // Only initialize features based on the current active set
        initializeFeatures(activeFeatures);
    } else {
        log('debug', "[Janus Debug] Effective state is inactive (or paused). Running cleanupFeatures for all previously active...");
        // Cleanup based on the features that *were* active
        cleanupFeatures(previousActiveFeatures); // Cleanup all features that might have been active
        deactivateJanus(); // General cleanup (reverting text nodes)
    }
}

// --- Feature Initialization/Cleanup ---

function initializeFeatures(featuresToInit) {
    log('debug', "[Janus Debug] Initializing features:", featuresToInit);

    // Ensure basic styles and tooltip div are present if relevant features are active
    if (featuresToInit.includes(FeatureKeys.CORE_TRANSLATION) || featuresToInit.includes(FeatureKeys.TOOLTIP)) {
        if (!document.getElementById('janus-tooltip')) {
            createTooltip();
            injectStyles(); // Assuming styles are general or tooltip-related
        }
    }

    // Initialize Core Translation/Highlighting
    if (featuresToInit.includes(FeatureKeys.CORE_TRANSLATION)) {
        activateJanus('initializeFeatures'); // Call the main activation logic
    }

    // Setup listeners based on features
    setupEventListeners(); // For now, setup all listeners, individual checks happen within handlers
    // TODO: Potentially only add listeners if TOOLTIP or CLICK_TO_TOGGLE is active
}

function cleanupFeatures(featuresToCleanup) {
    log('debug', "[Janus Debug] Cleaning up features:", featuresToCleanup);

    // If core translation is being cleaned up, revert words
    if (featuresToCleanup.includes(FeatureKeys.CORE_TRANSLATION)) {
        // Note: deactivateJanus handles the text node reversion.
        // Ensure it's called if CORE_TRANSLATION is cleaned up while *inactive*.
        // If called while *active* due to feature change, deactivateJanus might run twice (here implicitly, and below explicitly). Needs refinement.
        // For now, rely on the main handleStateChange logic calling deactivateJanus when becoming inactive.
    }

    // Remove Tooltip Element if no longer needed
    if (featuresToCleanup.includes(FeatureKeys.TOOLTIP)) {
        if (tooltipElement) {
            tooltipElement.remove();
            tooltipElement = null;
            log('debug', "[Janus Debug] Removed tooltip element.");
        }
    }

    // Remove listeners (consider removing only if BOTH tooltip and click-toggle are off)
    if (featuresToCleanup.includes(FeatureKeys.TOOLTIP) || featuresToCleanup.includes(FeatureKeys.CLICK_TO_TOGGLE)) {
         // If *neither* feature requiring listeners is active anymore, remove them.
         if (!activeFeatures.includes(FeatureKeys.TOOLTIP) && !activeFeatures.includes(FeatureKeys.CLICK_TO_TOGGLE)) {
             removeEventListeners();
         }
    }
    // Note: Styles injected by injectStyles are not removed currently.
}

// --- End Feature Initialization/Cleanup ---

// --- Event Listeners (using delegation) ---

function handleMouseOver(event) {
    // Check if the tooltip feature is active AND the extension is generally active
    if (activeFeatures.includes(FeatureKeys.TOOLTIP) && currentIsActive && event.target.classList.contains(translatedClass)) {
        const originalWord = event.target.dataset.original || 'Original word not found';
        showTooltip(event, originalWord);
    }
}

function handleMouseOut(event) {
    // Tooltip hiding doesn't strictly need the feature check, but good practice
    if (activeFeatures.includes(FeatureKeys.TOOLTIP) && currentIsActive && event.target.classList.contains(translatedClass)) {
        hideTooltip();
    }
}

function handleClick(event) {
    // Check if the click-to-toggle feature is active AND the extension is generally active
    if (activeFeatures.includes(FeatureKeys.CLICK_TO_TOGGLE) && currentIsActive && event.target.classList.contains(translatedClass)) {
        // Existing logic to get allowToggle setting (could be simplified if allowToggle becomes a feature flag itself)
        getJanusSettings(Object.values(settingsKeys), (result) => {
            const allowToggle = result[settingsKeys.allowToggle];

            // Only toggle if the setting allows it
            if (allowToggle) {
                const span = event.target;
                const currentState = span.dataset.janusState;

                if (currentState === 'translated') {
                    // Switch to original
                    span.textContent = span.dataset.original;
                    span.dataset.janusState = 'original';
                } else {
                    // Switch back to translated
                    span.textContent = span.dataset.translated;
                    span.dataset.janusState = 'translated';
                }
            }

            hideTooltip(); // Hide tooltip after click, regardless of toggle
        });
    }
}

function setupEventListeners() {
    if (listenersActive) return;
    document.body.addEventListener('mouseover', handleMouseOver);
    document.body.addEventListener('mouseout', handleMouseOut);
    document.body.addEventListener('click', handleClick);
    listenersActive = true;
    log('debug', '[Janus] Event listeners attached.');
}

function removeEventListeners() {
    if (!listenersActive) return;
    document.body.removeEventListener('mouseover', handleMouseOver);
    document.body.removeEventListener('mouseout', handleMouseOut);
    document.body.removeEventListener('click', handleClick);
    listenersActive = false;
    log('debug', '[Janus] Event listeners removed.');
}

// --- State Handling & Initialization ---

// 1. Get initial state when the script loads
log('debug', "Requesting initial state from background script...");
chrome.runtime.sendMessage({ action: 'getContentScriptState' }, (response) => {
    if (chrome.runtime.lastError) {
        log('error', "Error getting initial state:", chrome.runtime.lastError.message);
        // Potentially retry or default to inactive
        handleStateChange(false, null, []); // Initialize with empty features
        return;
    }
    if (response && response.success) {
        log('debug', "Received initial state:", response.currentState, "Pause End:", response.pauseEndTime ? new Date(response.pauseEndTime).toLocaleString() : null, "Features:", response.activeFeatures);
        // Call handleStateChange with all values
        handleStateChange(response.currentState, response.pauseEndTime, response.activeFeatures || []);
    } else {
        log('error', "Failed to get initial state:");
        handleStateChange(false, null, []); // Default to inactive/empty features on failure
    }
});

// 2. Listen for changes in storage
chrome.storage.onChanged.addListener((changes, namespace) => {
    let stateChanged = false;
    let pauseChanged = false;
    let settingsChanged = false;
    let featuresNeedRefetch = false; // Flag to check if features might need re-evaluation

    if (namespace === 'local') {
        // Determine the new state values, defaulting to current cached values if no change occurred
        let newIsActive = currentIsActive;
        let newPauseEndTime = currentPauseEndTime;

        if (changes[stateKey]) {
            newIsActive = changes[stateKey].newValue;
            log('debug', `Storage changed! Key: ${stateKey}, New value: ${newIsActive}`);
            stateChanged = true;
        }
        if (changes[pauseEndTimeKey]) {
            newPauseEndTime = changes[pauseEndTimeKey].newValue;
            log('debug', `Storage changed! Key: ${pauseEndTimeKey}, New value: ${newPauseEndTime ? new Date(newPauseEndTime).toLocaleString() : null}`);
            pauseChanged = true;
        }
        // Check if settings that require refresh changed
        if (changes[settingsKeys.targetLang] || changes[settingsKeys.maxBlocks] || changes[settingsKeys.difficultyLevel]) {
            const changedKey = changes[settingsKeys.targetLang] ? settingsKeys.targetLang :
                              (changes[settingsKeys.maxBlocks] ? settingsKeys.maxBlocks : settingsKeys.difficultyLevel);
            log('debug', `Storage changed! Key: ${changedKey}, New value: ${changes[changedKey].newValue}`);
            settingsChanged = true;
            featuresNeedRefetch = true; // Settings change might affect features
        }
        
        // Check if allow toggle changed (doesn't require refresh)
        if (changes[settingsKeys.allowToggle]) {
            log('debug', `Storage changed! Key: ${settingsKeys.allowToggle}, New value: ${changes[settingsKeys.allowToggle].newValue}`);
            // No 'settingsChanged = true' here as it doesn't mandate a content refresh
        }

        // --- Call handleStateChange only if state or pause potentially changed --- 
        if (stateChanged || pauseChanged) {
            log('debug', "State or Pause changed in storage, calling handleStateChange...");
            // Fetch active features as state changes might affect them (especially pause)
            chrome.runtime.sendMessage({ action: 'getContentScriptState' }, (response) => {
                 if (response && response.success) {
                     // Pass the potentially new state values directly
                     handleStateChange(newIsActive, newPauseEndTime, response.activeFeatures || []);
                 } else {
                      log('warn', "[Janus Debug] Could not re-fetch features on state/pause change, using previous.");
                      // Pass new state but fallback to existing cached features
                      handleStateChange(newIsActive, newPauseEndTime, activeFeatures);
                 }
            });
        }
        // If only settings changed (but state/pause didn't), trigger refresh IF needed
        else if (settingsChanged) {
            log('debug', "Only Settings changed in storage, checking if refresh needed...");
            const now = Date.now();
            // Use the *potentially updated* newIsActive and newPauseEndTime for the check
            const isPaused = newPauseEndTime && newPauseEndTime > now;
            const isEffectivelyActive = newIsActive && !isPaused;
            
            if (isEffectivelyActive) {
                log('debug', "[Janus Debug] Re-activating Janus due to relevant settings change.");
                chrome.runtime.sendMessage({ action: 'getContentScriptState' }, (response) => {
                    const features = (response && response.success) ? response.activeFeatures : activeFeatures; 
                    // Deactivate first (using false state, null pause, empty features)
                    handleStateChange(false, null, []); 
                    // Then re-activate with the current state/pause and potentially new features
                    handleStateChange(newIsActive, newPauseEndTime, features);
                 });
            } else {
                log('debug', "[Janus Debug] Settings changed but Janus is currently inactive or paused. No refresh needed.");
            }
        }
    }
});

// --- Message Listener for Navigation and Settings Updates ---

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  log('debug', "[Janus Debug] Received message:", message);

  if (message.action === 'janusPageNavigated') {
    log('debug', "[Janus Debug] Processing janusPageNavigated message.");
    // Check if effectively active state is still true
    const now = Date.now();
    const isPaused = currentPauseEndTime && currentPauseEndTime > now;
    const isEffectivelyActive = currentIsActive && !isPaused;

    if (isEffectivelyActive) {
        log('debug', "[Janus Debug] Re-activating Janus due to navigation (effectively active).");
        // Re-fetch features on navigation
        chrome.runtime.sendMessage({ action: 'getContentScriptState' }, (response) => {
            const features = (response && response.success) ? response.activeFeatures : activeFeatures;
            // Deactivate first
            handleStateChange(false, null, []);
            // Then re-activate
            handleStateChange(true, currentPauseEndTime, features);
            sendResponse({ success: true, action: "refreshed for navigation" });
        });
        return true; // Indicate async response
    } else {
        log('debug', "[Janus Debug] Received janusPageNavigated but Janus is currently effectively inactive or paused.");
        sendResponse({ success: false, reason: "Inactive or Paused" });
    }
    return true; // Indicate async response

  } else if (message.action === 'janusSettingsUpdated') {
    log('debug', "[Janus Debug] Processing janusSettingsUpdated message.");
    // Check if effectively active state is true before refreshing
    const now = Date.now();
    const isPaused = currentPauseEndTime && currentPauseEndTime > now;
    const isEffectivelyActive = currentIsActive && !isPaused;

    if (isEffectivelyActive) {
        log('debug', "[Janus Debug] Re-activating Janus due to settings update (effectively active).");
        // Re-fetch features on settings update from popup
        chrome.runtime.sendMessage({ action: 'getContentScriptState' }, (response) => {
            const features = (response && response.success) ? response.activeFeatures : activeFeatures;
             // Deactivate first
            handleStateChange(false, null, []);
            // Then re-activate
            handleStateChange(true, currentPauseEndTime, features);
            sendResponse({ success: true, action: "refreshed for settings" });
        });
        return true; // Indicate async response
    } else {
        log('debug', "[Janus Debug] Received janusSettingsUpdated but Janus is currently effectively inactive or paused. No refresh needed.");
        sendResponse({ success: false, reason: "Inactive or Paused" });
    }
    return true; // Indicate async response

  } else {
      log('debug', "[Janus Debug] Received unhandled message action:", message.action);
  }

  // Default return false if no async response is needed for other message types
  return false;
});

log('debug', "Content script setup complete. Listening for state changes, navigation, and settings updates.");

