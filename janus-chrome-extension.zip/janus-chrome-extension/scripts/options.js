// Shared settings keys (consistency with content.js)
const settingsKeys = {
    maxWords: 'janusMaxWords',
    targetLang: 'janusTargetLang',
    azureUrl: 'janusAzureUrl' // New key for Azure URL
};

const defaultSettings = {
    [settingsKeys.maxWords]: 5,
    [settingsKeys.targetLang]: 'es',
    [settingsKeys.azureUrl]: '' // Default Azure URL is empty
};

// Saves options to chrome.storage
function saveOptions() {
    const maxWords = document.getElementById('max-words').value;
    const targetLang = document.getElementById('target-lang').value;
    const azureUrl = document.getElementById('azure-url').value.trim(); // Trim whitespace

    const settingsToSave = {
        [settingsKeys.maxWords]: parseInt(maxWords, 10) || defaultSettings[settingsKeys.maxWords], // Ensure it's a number
        [settingsKeys.targetLang]: targetLang,
        [settingsKeys.azureUrl]: azureUrl // Save the URL
    };

    chrome.storage.local.set(settingsToSave, () => {
        // Update status to let user know options were saved.
        const status = document.getElementById('status');
        status.textContent = 'Options saved.';
        setTimeout(() => {
            status.textContent = '';
        }, 1500);
        console.log("Janus settings saved:", settingsToSave);
    });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function loadOptions() {
    // Get all keys, providing defaults
    chrome.storage.local.get(defaultSettings, (items) => {
        if (chrome.runtime.lastError) {
            console.error("Error loading settings:", chrome.runtime.lastError);
            // Use defaults if error occurs
            document.getElementById('max-words').value = defaultSettings[settingsKeys.maxWords];
            document.getElementById('target-lang').value = defaultSettings[settingsKeys.targetLang];
            document.getElementById('azure-url').value = defaultSettings[settingsKeys.azureUrl];
            return;
        }
        console.log("Loaded settings:", items);
        document.getElementById('max-words').value = items[settingsKeys.maxWords];
        document.getElementById('target-lang').value = items[settingsKeys.targetLang];
        document.getElementById('azure-url').value = items[settingsKeys.azureUrl];
    });
}

document.addEventListener('DOMContentLoaded', loadOptions);
document.getElementById('save').addEventListener('click', saveOptions);

console.log("Options script loaded."); 