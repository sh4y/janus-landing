console.log("Janus background script loaded.");

// Default keys for storage
const stateKey = 'janusIsActive';
const pauseEndTimeKey = 'janusPauseEndTime'; // Key for pause end time

// Initialize state in memory
let isActiveInMemory = false;
let pauseEndTimeInMemory = null; // Add memory cache for pause time
let resumeTimerId = null; // To hold the setTimeout ID

// Define the default Azure Function URL
const DEFAULT_AZURE_FUNCTION_URL = "https://janustranslate-apim.azure-api.net/translate/TranslateWords";

// Shared settings keys (needed here too)
const settingsKeys = {
    azureUrl: 'janusAzureUrl',
    targetLang: 'janusTargetLang',
    maxWords: 'janusMaxWords'
};

// Updated default settings object for clarity when fetching multiple keys
const defaultStorageValues = {
    [stateKey]: false, // Default active state is false until set otherwise
    [pauseEndTimeKey]: null, // Default pause end time is null (not paused)
    [settingsKeys.azureUrl]: '', // Default Azure URL is empty until set
    [settingsKeys.targetLang]: 'es', // Added default target language ('es' = Spanish)
    [settingsKeys.maxWords]: 5 // Added default max words
};

// Remove or comment out the hardcoded URL constant
// const AZURE_FUNCTION_URL = "YOUR_AZURE_FUNCTION_URL_HERE";

// Import premium functionality
import { isPremiumUser, getPremiumFeatures, applyPremiumFeaturesToRequest } from '../utils/premium.js';

// --- Feature Flags ---
// Remove or comment out the existing Features object with premium flags
// const Features = { ... };

// Function to determine which features are currently active for the user
async function getActiveFeatures() {
    // Get premium status
    const isPremium = await isPremiumUser();
    const premiumFeatures = await getPremiumFeatures();
    
    // Core features always enabled
    const activeFeatures = [
        'coreTranslation',
        'tooltip',
        'clickToToggle',
        'wordCountLimit',
        'pauseFunctionality'
    ];
    
    // Add premium features if user is premium
    if (isPremium) {
        Object.values(premiumFeatures).forEach(feature => {
            if (feature.enabled) {
                activeFeatures.push(feature.key);
            }
        });
    }
    
    console.log("[Janus BG Features] Active features determined:", activeFeatures);
    return activeFeatures;
}

// --- End Feature Flags ---

// Function to get state AND pause state from storage
function getStateAndPause(callback) {
  chrome.storage.local.get([stateKey, pauseEndTimeKey], (result) => {
    const currentState = result[stateKey] || false;
    const currentPauseEndTime = result[pauseEndTimeKey];
    isActiveInMemory = currentState;
    pauseEndTimeInMemory = currentPauseEndTime;
    console.log("State & Pause retrieved:", currentState, currentPauseEndTime);
    if (callback) callback(currentState, currentPauseEndTime);
  });
}

// Function to set state in storage
function setState(newState, callback) {
  isActiveInMemory = newState; // Update memory cache immediately
  // If activating, ensure any pause is cleared
  const updateData = { [stateKey]: newState };
  if (newState === true && pauseEndTimeInMemory) {
      console.log("Activating manually, clearing pause state and timer.");
      // Clear the timeout if it exists
      if (resumeTimerId) {
          clearTimeout(resumeTimerId);
          resumeTimerId = null;
      }
      updateData[pauseEndTimeKey] = null; // Clear pause end time from storage
      pauseEndTimeInMemory = null;
  }
  chrome.storage.local.set(updateData, () => {
    console.log(`State saved: ${newState}. Pause state potentially cleared.`);
    if (callback) callback();
  });
}

// Function to check and potentially clear expired pause
function checkAndClearExpiredPause(callback) {
    const now = Date.now();
    if (pauseEndTimeInMemory && pauseEndTimeInMemory <= now) {
        console.log("Pause time expired, clearing from storage.");
        chrome.storage.local.remove(pauseEndTimeKey, () => {
            if (chrome.runtime.lastError) {
                console.error("Error clearing expired pause:", chrome.runtime.lastError);
            } else {
                pauseEndTimeInMemory = null;
                console.log("Expired pause time cleared.");
            }
            if (callback) callback();
        });
    } else {
        if (callback) callback();
    }
}

// Function to handle the resume timer firing
function handleResumeTimerFired(expectedEndTime) {
    console.log("Resume timer fired.");
    resumeTimerId = null; // Clear the timer ID

    // Double-check if the pause is still the one we set the timer for
    // and hasn't been manually cleared or changed since.
    if (pauseEndTimeInMemory && pauseEndTimeInMemory === expectedEndTime) {
        console.log("Pause end time matches expected. Resuming automatically.");
        chrome.storage.local.remove(pauseEndTimeKey, () => {
            if (chrome.runtime.lastError) {
                console.error("Error removing pause time on timer fire:", chrome.runtime.lastError);
            } else {
                pauseEndTimeInMemory = null;
                console.log("Pause automatically ended. State cleared from storage.");
                // Potentially notify content scripts if needed, but storage change listener should handle UI
            }
        });
    } else {
        console.log("Pause was cleared or changed before timer fired. No action needed.");
    }
}

// Function to start or restart the resume timer based on current pause state
function restartResumeTimerIfNeeded() {
    // Clear any existing timer first
    if (resumeTimerId) {
        clearTimeout(resumeTimerId);
        resumeTimerId = null;
        console.log("Cleared existing resume timer before restarting.");
    }

    const now = Date.now();
    if (pauseEndTimeInMemory && pauseEndTimeInMemory > now) {
        const delay = pauseEndTimeInMemory - now;
        console.log(`Restarting resume timer. Delay: ${delay}ms`);
        resumeTimerId = setTimeout(() => {
            // Pass the specific end time to the handler
            handleResumeTimerFired(pauseEndTimeInMemory);
        }, delay);
    } else {
        console.log("No active pause requiring timer restart.");
    }
}

// Initialize on install/update
chrome.runtime.onInstalled.addListener(async (details) => {
    console.log(`Installation/Update reason: ${details.reason}`);

    // On first install
    if (details.reason === "install") {
        console.log("[Janus Install] First install detected. Requesting registration...");

        // Set initial non-ID values first
        await new Promise((resolve) => {
            chrome.storage.local.set({
                [stateKey]: true,
                [pauseEndTimeKey]: null, // Ensure pause is null initially
                [settingsKeys.azureUrl]: DEFAULT_AZURE_FUNCTION_URL,
                [settingsKeys.targetLang]: defaultStorageValues[settingsKeys.targetLang], // Set default target lang
                [settingsKeys.maxWords]: defaultStorageValues[settingsKeys.maxWords], // Set default max words
            }, () => {
                isActiveInMemory = true;
                pauseEndTimeInMemory = null;
                console.log("Extension installed. Initial non-ID state saved. Requesting install ID...");
                resolve();
            });
        });

        // --- BEGIN: Call RegisterInstallation Function on First Install ---
        const registrationFunctionUrl = "https://janustranslate-apim.azure-api.net/translate/RegisterInstallation";
        const registrationMetadata = {
            browser: navigator.userAgent || "Unknown",
            installTime: new Date().toISOString()
        };

        try {
            const response = await fetch(registrationFunctionUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    metadata: registrationMetadata
                }),
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`[Janus Install] RegisterInstallation HTTP error: ${response.status} - ${errorText}`);
            } else {
                const data = await response.json();
                console.log("[Janus Install] Successfully called RegisterInstallation:", data);

                if (data && data.success && data.installationId) {
                    // Save the received installation ID using the CORRECT key: 'installationId'
                    await new Promise((resolve) => {
                        chrome.storage.local.set({ installationId: data.installationId }, () => {
                            console.log("[Janus Install] Received and saved installation ID:", data.installationId);
                            resolve();
                        });
                    });
                } else {
                    console.error("[Janus Install] Registration call succeeded but response lacked success or installationId:", data);
                }
            }
        } catch (error) {
            console.error("[Janus Install] Error calling RegisterInstallation function:", error);
        }
        // --- END: Call RegisterInstallation Function on First Install ---

        console.log("[Janus Install] onInstalled listener finished for 'install' reason.");

    } else if (details.reason === "update") {
        console.log("Extension updated. Checking settings & pause state...");
        // On update, ensure settings exist, load state, check pause
        await new Promise((resolve) => {
             chrome.storage.local.get(defaultStorageValues, (settings) => {
                let settingsToUpdate = {};
                let settingWasMissing = false;

                // Check URL
                if (!settings[settingsKeys.azureUrl] || typeof settings[settingsKeys.azureUrl] !== 'string' || !settings[settingsKeys.azureUrl].startsWith('http')) {
                    settingsToUpdate[settingsKeys.azureUrl] = DEFAULT_AZURE_FUNCTION_URL;
                    settingWasMissing = true;
                }
                // Check targetLang
                if (!settings[settingsKeys.targetLang] || typeof settings[settingsKeys.targetLang] !== 'string') {
                    settingsToUpdate[settingsKeys.targetLang] = defaultStorageValues[settingsKeys.targetLang];
                    settingWasMissing = true;
                }
                // Check maxWords
                if (typeof settings[settingsKeys.maxWords] !== 'number' || settings[settingsKeys.maxWords] < 0 || settings[settingsKeys.maxWords] > 50) {
                    settingsToUpdate[settingsKeys.maxWords] = defaultStorageValues[settingsKeys.maxWords];
                    settingWasMissing = true;
                }

                // If any setting was missing/invalid, update storage
                if (settingWasMissing) {
                    console.log("Updating missing/invalid settings on update:", settingsToUpdate);
                    chrome.storage.local.set(settingsToUpdate, () => {
                        if (chrome.runtime.lastError) {
                            console.error("Error saving default settings on update:", chrome.runtime.lastError);
                        }
                        // After potential update, load current state and check pause
                         getStateAndPause(() => {
                            checkAndClearExpiredPause(restartResumeTimerIfNeeded);
                            resolve();
                        });
                    });
                } else {
                    console.log("All settings present and valid on update.");
                    // If no settings needed updating, still load state and check pause
                    getStateAndPause(() => {
                        checkAndClearExpiredPause(restartResumeTimerIfNeeded);
                        resolve();
                    });
                }
            });
        });
         console.log("[Janus Update] onInstalled listener finished for 'update' reason.");
    } else {
         console.log("[Janus Other] onInstalled listener finished for reason:", details.reason);
    }
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received message:", message.action, "from", sender.tab ? "tab " + sender.tab.id : "popup/extension");

  if (message.action === 'toggleState') {
    const newState = !isActiveInMemory;
    setState(newState, () => {
      // Send the new state back to the popup
      sendResponse({ success: true, newState: newState });
    });
    // Indicate async response
    return true;
  } else if (message.action === 'getState' || message.action === 'getContentScriptState') {
    // Get the active feature list as well
    getActiveFeatures().then(features => {
        getStateAndPause((currentState, currentPauseEndTime) => {
            sendResponse({ success: true, currentState: currentState, pauseEndTime: currentPauseEndTime, activeFeatures: features }); // Send all info
        });
    });
    // Indicate async response
    return true;
  } else if (message.action === 'translateWords') {
      // Check pause state before translating
      const now = Date.now();
      if (pauseEndTimeInMemory && pauseEndTimeInMemory > now) {
          console.log("[Janus BG] Translation requested while paused. Ignoring.");
          sendResponse({ success: false, error: "Translation paused.", paused: true });
          return false; // No async response needed
      }

      // Handle bulk translation request
      if (!message.words || !Array.isArray(message.words) || message.words.length === 0) {
          console.error("[Janus BG] Invalid 'translateWords' request: Missing or empty words array.");
          sendResponse({ success: false, error: "Invalid input: words array is missing or empty." });
          return false;
      }

      const wordsToTranslate = message.words;

      // 1. Get the configured Azure URL, Target Lang, and Max Words from storage
      chrome.storage.local.get(defaultStorageValues, (settings) => {
          if (chrome.runtime.lastError) {
              console.error("[Janus BG] Error retrieving settings for translation:", chrome.runtime.lastError);
              sendResponse({ success: false, error: "Could not retrieve settings (URL/Lang/MaxWords)." });
              // Note: No return true needed here, as this callback itself is synchronous
              // The outer handler needs to return true for the storage.get call.
              return;
          }

          const azureUrl = settings[settingsKeys.azureUrl];
          const targetLang = settings[settingsKeys.targetLang];
          const maxWords = settings[settingsKeys.maxWords]; // Retrieve maxWords

          // 2. Validate URL
          if (!azureUrl || typeof azureUrl !== 'string' || !azureUrl.startsWith('http')) {
              console.error("[Janus BG] Invalid or missing Azure Function URL:", azureUrl);
              sendResponse({ success: false, error: "Azure Function URL not configured/invalid." });
              return;
          }

          // 3. Validate target language
          if (!targetLang || typeof targetLang !== 'string' || targetLang.length < 2) {
              console.error("[Janus BG] Invalid or missing Target Language:", targetLang);
              sendResponse({ success: false, error: "Target Language not configured/invalid." });
              return;
          }

          // 4. Validate maxWords (allow 0 for disabled state handled by content script)
          if (typeof maxWords !== 'number' || maxWords < 0 || maxWords > 50) {
               console.error("[Janus BG] Invalid Max Words setting:", maxWords);
               sendResponse({ success: false, error: "Max Words setting invalid." });
               return;
          }

          console.log(`[Janus BG] Using Azure URL: ${azureUrl}`);
          console.log(`[Janus BG] Using Target Lang: ${targetLang}`);
          console.log(`[Janus BG] Using Max Words: ${maxWords}`);
          console.log(`[Janus BG] Received request to translate ${wordsToTranslate.length} words.`);

          // 5. Get the installId from storage using the CORRECT key: 'installationId'
          chrome.storage.local.get(['installationId'], (idResult) => { 
              if (chrome.runtime.lastError || !idResult.installationId) {
                  // Handle error: Could not retrieve ID
                  if (chrome.runtime.lastError) {
                    console.error("[Janus BG] Error retrieving install ID:", chrome.runtime.lastError.message);
                    sendResponse({ success: false, error: `Could not retrieve install ID due to storage error: ${chrome.runtime.lastError.message}` });
                  } else {
                    console.error("[Janus BG] Install ID not found in storage.");
                    sendResponse({ success: false, error: "Could not retrieve install ID: ID not found in storage." });
                  }
                  return; // Stop processing if ID is missing
              }

              const installId = idResult.installationId; // Use the correct key
              console.log(`[Janus BG] Using Install ID: ${installId}`);

              // 6. Construct the request body (NOW INCLUDING installId)
              const requestBody = {
                  installId: installId, // Add the installation ID
                  words: wordsToTranslate,
                  targetLang: targetLang,
                  to: targetLang, // Included for compatibility/potential use by function
              };

              // 7. Make the fetch call with timeout
              console.log("[Janus BG] Sending fetch request to:", azureUrl);
              
              // Create an AbortController to implement fetch timeout
              const controller = new AbortController();
              const timeoutId = setTimeout(() => {
                  console.log("[Janus BG] Fetch request timed out after 30 seconds");
                  controller.abort();
              }, 30000); // 30-second timeout
              
              fetch(azureUrl, {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json'
                      // No Ocp-Apim-Subscription-Key needed now
                  },
                  body: JSON.stringify(requestBody),
                  signal: controller.signal // Add the abort signal
              })
              .then(response => {
                  clearTimeout(timeoutId); // Clear the timeout on successful response
                  console.log("[Janus BG] Received fetch response:", response.status);
                  if (!response.ok) {
                      return response.text().then(text => {
                          console.error(`[Janus BG] HTTP error response body: ${text}`);
                          throw new Error(`HTTP error! status: ${response.status}, message: ${text}`);
                      });
                  }
                  return response.json();
              })
              .then(data => {
                  if (data && Array.isArray(data.translations)) {
                      console.log("[Janus BG] Received successful translations:", data.translations.length);
                      sendResponse({ success: true, translations: data.translations });
                  } else {
                      console.error("[Janus BG] Invalid or unexpected response format from API:", data);
                      sendResponse({ success: false, error: "Invalid response format from API.", details: data });
                  }
              })
              .catch(error => {
                  clearTimeout(timeoutId); // Clear the timeout on error as well
                  console.error('[Janus BG] Fetch error:', error.name, error.message);
                  
                  // Check if it was a timeout
                  if (error.name === 'AbortError') {
                      sendResponse({ success: false, error: 'Request timed out after 30 seconds' });
                  } else {
                      sendResponse({ success: false, error: `Fetch error: ${error.message}` });
                  }
              });

              // Note: No 'return true;' here needed because we are already inside the scope
              // of the outer message listener which should have returned true.

          }); // End of storage.local.get for installId

          // **CRUCIAL:** This outer storage call IS asynchronous.
          // We need to return true *here* to keep the port open for BOTH storage.get calls AND the fetch.
          return true;

      }); // End of chrome.storage.local.get callback for settings

      // **CRUCIAL:** We need to return true *here* as well, because the outer chrome.storage.local.get is async.
      return true;

  } else {
       // Handle other message types or ignore
       console.log("[Janus BG] Unhandled message action:", message.action);
       return false; // No async response for unhandled actions
  }
}); // End of chrome.runtime.onMessage.addListener

// Handle API requests to Azure Function
async function fetchTranslations(textContent, settings) {
    try {
        // Build base request data
        let requestData = {
            textContent,
            targetLanguage: settings.targetLang,
            wordsPerPage: settings.maxWords,
            difficultyLevel: settings.difficultyLevel || 'beginner'
        };
        
        // Apply premium features to request if available
        requestData = await applyPremiumFeaturesToRequest(requestData);
        
        // Send request to Azure Function
        const response = await fetch(settings.azureUrl || DEFAULT_AZURE_FUNCTION_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });
        
        // Parse response
        if (!response.ok) {
            throw new Error(`API call failed with status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error("[Janus BG] Error fetching translations:", error);
        return { error: error.message };
    }
}